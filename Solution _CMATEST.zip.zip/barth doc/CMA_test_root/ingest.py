#!/usr/bin/env python3
"""
ingest.py - CMA Data Engineer Technical Test
ETL pipeline for cleaning and enriching listings data
"""

import argparse
import logging
import os
import json
from typing import Tuple

import pandas as pd


def setup_logging(log_dir: str) -> None:
    """
    Configure logging to file and console.
    """
    os.makedirs(log_dir, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(os.path.join(log_dir, "pipeline.log")),
            logging.StreamHandler()
        ]
    )


def read_csv(file_path: str) -> pd.DataFrame:
    """
    Read a CSV file into a DataFrame.
    """
    logging.info(f"Reading CSV: {file_path}")
    return pd.read_csv(file_path)


def clean_and_validate(df: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """
    Clean and validate the listings data:
    - Drop rows missing required columns
    - Ensure positive numeric price
    - Parse dates
    - Deduplicate on (date, item_id)
    """
    required_cols = ["date", "seller_id", "region", "category", "item_id", "price_gbp"]
    source_rows = len(df)

    # Check for required columns
    missing_cols = [c for c in required_cols if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    # Drop rows missing required fields
    df_required = df.dropna(subset=required_cols).copy()
    dropped_missing_required = source_rows - len(df_required)

    # Ensure price is numeric and positive
    df_required["price_gbp"] = pd.to_numeric(df_required["price_gbp"], errors="coerce")
    df_valid_price = df_required[df_required["price_gbp"] > 0].copy()
    dropped_non_positive_price = len(df_required) - len(df_valid_price)

    # Parse dates
    df_valid_price["date"] = pd.to_datetime(df_valid_price["date"], errors="coerce", dayfirst=True)
    df_valid_price = df_valid_price.dropna(subset=["date"]).copy()

    # Deduplicate
    valid_rows_after_clean = len(df_valid_price)
    df_dedup = df_valid_price.drop_duplicates(subset=["date", "item_id"], keep="last")
    rows_after_dedup = len(df_dedup)

    dq_metrics = {
        "source_rows": source_rows,
        "valid_rows_after_clean": valid_rows_after_clean,
        "rows_after_dedup": rows_after_dedup,
        "dropped_non_positive_price": dropped_non_positive_price,
        "dropped_missing_required": dropped_missing_required
    }

    logging.info(f"Data Quality Metrics: {json.dumps(dq_metrics, indent=2)}")
    return df_dedup, dq_metrics


def enrich_data(df: pd.DataFrame, lookup_df: pd.DataFrame) -> pd.DataFrame:
    """
    Enrich listings data with category-to-segment mapping.
    """
    logging.info("Enriching data with category lookup")
    enriched_df = df.merge(lookup_df, on="category", how="left")
    if "segment" not in enriched_df.columns:
        enriched_df["segment"] = ""
    return enriched_df


def save_outputs(df: pd.DataFrame, dq_metrics: dict, out_dir: str) -> None:
    """
    Save outputs:
    - Parquet file (snappy-compressed) in out/processed/
    - Data quality report as JSON in out/
    """
    # Parquet
    processed_dir = os.path.join(out_dir, "processed")
    os.makedirs(processed_dir, exist_ok=True)
    parquet_path = os.path.join(processed_dir, "data.parquet")
    df.to_parquet(parquet_path, engine="pyarrow", compression="snappy", index=False)
    logging.info(f"Saved cleaned Parquet file: {parquet_path}")

    # Data quality report
    dq_path = os.path.join(out_dir, "dq_report.json")
    with open(dq_path, "w") as f:
        json.dump(dq_metrics, f, indent=4)
    logging.info(f"Saved data quality report: {dq_path}")


def main():
    parser = argparse.ArgumentParser(description="CMA Data Engineer ETL pipeline")
    parser.add_argument("--listings", required=True, help="Path to listings.csv")
    parser.add_argument("--lookup", required=True, help="Path to category_lookup.csv")
    parser.add_argument("--out", required=True, help="Output directory")
    args = parser.parse_args()

    log_dir = os.path.join(args.out, "logs")
    setup_logging(log_dir)

    listings_df = read_csv(args.listings)
    lookup_df = read_csv(args.lookup)

    cleaned_df, dq_metrics = clean_and_validate(listings_df)
    enriched_df = enrich_data(cleaned_df, lookup_df)
    save_outputs(enriched_df, dq_metrics, args.out)

    logging.info("ETL pipeline completed successfully.")


if __name__ == "__main__":
    main()
